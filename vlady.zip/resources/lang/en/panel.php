<?php

return [
    'site_title' => 'Vlady Admin Panel',
];
