<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.event.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.events.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name"><?php echo e(trans('cruds.event.fields.name')); ?>*</label>
                <input type="text" id="name" name="name" class="form-control"
                    value="<?php echo e(old('name', isset($event) ? $event->name : '')); ?>" required>
                <?php if($errors->has('name')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('name')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.event.fields.name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('location_name') ? 'has-error' : ''); ?>">
                <label for="location_name"><?php echo e(trans('cruds.event.fields.location_name')); ?>*</label>
                <input type="text" id="location_name" name="location_name" class="form-control"
                    value="<?php echo e(old('location_name', isset($event) ? $event->location_name : '')); ?>" required>
                <?php if($errors->has('location_name')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('location_name')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.event.fields.location_name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                <label for="address"><?php echo e(trans('cruds.event.fields.address')); ?>*</label>
                <textarea id="address" name="address" class="form-control "
                    required><?php echo e(old('address', isset($event) ? $event->address : '')); ?></textarea>
                <?php if($errors->has('address')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('address')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.event.fields.address_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('city') ? 'has-error' : ''); ?>">
                <label for="city"><?php echo e(trans('cruds.event.fields.city')); ?>*</label>
                <select id="city" name="city" class="form-control" required>
                    <option value="" disabled><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Event::CITY_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php echo e(old('city', 1) === (string)$key ? 'selected' : ''); ?>><?php echo e($label); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('city')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('city')); ?>

                </p>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('time') ? 'has-error' : ''); ?>">
                <label for="time"><?php echo e(trans('cruds.event.fields.time')); ?>*</label>
                <input type="text" id="time" name="time" class="form-control datetime"
                    value="<?php echo e(old('time', isset($event) ? $event->time : '')); ?>" required>
                <?php if($errors->has('time')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('time')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.event.fields.time_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
                <label for="price"><?php echo e(trans('cruds.event.fields.price')); ?>*</label>
                <input type="number" id="price" name="price" class="form-control"
                    value="<?php echo e(old('price', isset($event) ? $event->price : '')); ?>" step="0.01" required>
                <?php if($errors->has('price')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('price')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.event.fields.price_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('introduction') ? 'has-error' : ''); ?>">
                <label for="introduction"><?php echo e(trans('cruds.event.fields.introduction')); ?>*</label>
                <textarea id="introduction" name="introduction"
                    class="form-control ckeditor"><?php echo e(old('introduction', isset($event) ? $event->introduction : '')); ?></textarea>
                <?php if($errors->has('introduction')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('introduction')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.event.fields.introduction_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('content') ? 'has-error' : ''); ?>">
                <label for="content"><?php echo e(trans('cruds.event.fields.content')); ?>*</label>
                <textarea id="content" name="content"
                    class="form-control ckeditor"><?php echo e(old('content', isset($event) ? $event->content : '')); ?></textarea>
                <?php if($errors->has('content')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('content')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.event.fields.content_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('slug') ? 'has-error' : ''); ?>">
                <label for="slug"><?php echo e(trans('cruds.event.fields.slug')); ?>*</label>
                <input type="text" id="slug" name="slug" class="form-control" onkeyup="ChangeToSlug();"
                    onclick="ChangeToSlug();" value="<?php echo e(old('slug', isset($event) ? $event->slug : '')); ?>" required>
                <?php if($errors->has('slug')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('slug')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.event.fields.slug_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('event_cover') ? 'has-error' : ''); ?>">
                <label for="event_cover"><?php echo e(trans('cruds.event.fields.event_cover')); ?>*</label>
                <div class="needsclick dropzone" id="event_cover-dropzone">

                </div>
                <?php if($errors->has('event_cover')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('event_cover')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.event.fields.event_cover_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('video_link') ? 'has-error' : ''); ?>">
                <label for="video_link"><?php echo e(trans('cruds.event.fields.video_link')); ?></label>
                <textarea id="video_link" name="video_link"
                    class="form-control "><?php echo e(old('video_link', isset($event) ? $event->video_link : '')); ?></textarea>
                <?php if($errors->has('video_link')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('video_link')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.event.fields.video_link_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('event_image') ? 'has-error' : ''); ?>">
                <label for="event_image"><?php echo e(trans('cruds.event.fields.event_image')); ?></label>
                <div class="needsclick dropzone" id="event_image-dropzone">

                </div>
                <?php if($errors->has('event_image')): ?>
                <p class="help-block">
                    <?php echo e($errors->first('event_image')); ?>

                </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.event.fields.event_image_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function ChangeToSlug()
    {
        var name, slug;

        //Lấy text từ thẻ input title 
        name = document.getElementById("name").value;

        //Đổi chữ hoa thành chữ thường
        slug = name.toLowerCase();

        //Đổi ký tự có dấu thành không dấu
        slug = slug.replace(/á|à|ả|ạ|ã|ă|ắ|ằ|ẳ|ẵ|ặ|â|ấ|ầ|ẩ|ẫ|ậ/gi, 'a');
        slug = slug.replace(/é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ/gi, 'e');
        slug = slug.replace(/i|í|ì|ỉ|ĩ|ị/gi, 'i');
        slug = slug.replace(/ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ/gi, 'o');
        slug = slug.replace(/ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự/gi, 'u');
        slug = slug.replace(/ý|ỳ|ỷ|ỹ|ỵ/gi, 'y');
        slug = slug.replace(/đ/gi, 'd');
        //Xóa các ký tự đặt biệt
        slug = slug.replace(/\`|\~|\!|\@|\#|\||\$|\%|\^|\&|\*|\(|\)|\+|\=|\,|\.|\/|\?|\>|\<|\'|\"|\:|\;|_/gi, '');
        //Đổi khoảng trắng thành ký tự gạch ngang
        slug = slug.replace(/ /gi, "-");
        //Đổi nhiều ký tự gạch ngang liên tiếp thành 1 ký tự gạch ngang
        //Phòng trường hợp người nhập vào quá nhiều ký tự trắng
        slug = slug.replace(/\-\-\-\-\-/gi, '-');
        slug = slug.replace(/\-\-\-\-/gi, '-');
        slug = slug.replace(/\-\-\-/gi, '-');
        slug = slug.replace(/\-\-/gi, '-');
        //Xóa các ký tự gạch ngang ở đầu và cuối
        slug = '@' + slug + '@';
        slug = slug.replace(/\@\-|\-\@|\@/gi, '');
        //In slug ra textbox có id “slug”
        document.getElementById('slug').value = slug;
    }
</script>
<script>
    Dropzone.options.eventCoverDropzone = {
    url: '<?php echo e(route('admin.events.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="event_cover"]').remove()
      $('form').append('<input type="hidden" name="event_cover" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="event_cover"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($event) && $event->event_cover): ?>
      var file = <?php echo json_encode($event->event_cover); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, '<?php echo e($event->event_cover->getUrl('thumb')); ?>')
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="event_cover" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
<script>
    var uploadedEventImageMap = {}
Dropzone.options.eventImageDropzone = {
    url: '<?php echo e(route('admin.events.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').append('<input type="hidden" name="event_image[]" value="' + response.name + '">')
      uploadedEventImageMap[file.name] = response.name
    },
    removedfile: function (file) {
      console.log(file)
      file.previewElement.remove()
      var name = ''
      if (typeof file.file_name !== 'undefined') {
        name = file.file_name
      } else {
        name = uploadedEventImageMap[file.name]
      }
      $('form').find('input[name="event_image[]"][value="' + name + '"]').remove()
    },
    init: function () {
<?php if(isset($event) && $event->event_image): ?>
      var files =
        <?php echo json_encode($event->event_image); ?>

          for (var i in files) {
          var file = files[i]
          this.options.addedfile.call(this, file)
          this.options.thumbnail.call(this, file, file.url)
          file.previewElement.classList.add('dz-complete')
          $('form').append('<input type="hidden" name="event_image[]" value="' + file.file_name + '">')
        }
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vlady\resources\views/admin/events/create.blade.php ENDPATH**/ ?>