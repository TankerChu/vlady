<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="form-group">
            <label for="name"></label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old ('name')); ?>"
                placeholder="Tên Đầy Đủ Của Bạn">
            <?php if($errors->has('name')): ?>
            <small class="invalid-feedback"><?php echo e($errors -> first('name')); ?></small>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label for="phone"></label>
            <input type="text" name="phone" class="form-control" value="<?php echo e(old ('phone')); ?>"
                placeholder="Số điện thoại của bạn">
            <?php if($errors->has('phone')): ?>
            <small class="invalid-feedback"><?php echo e($errors -> first('phone')); ?></small>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="form-group">
            <label for="email"></label>
            <input type="text" name="email" class="form-control" value="<?php echo e(old ('email')); ?>" placeholder="Email Của Bạn">
            <?php if($errors->has('email')): ?>
            <small class="invalid-feedback"><?php echo e($errors -> first('email')); ?></small>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label for="city"></label>
            <input type="text" name="city" class="form-control" value="<?php echo e(old ('city')); ?>"
                placeholder="Thành phố hiện tại của bạn">
            <?php if($errors->has('city')): ?>
            <small class="invalid-feedback"><?php echo e($errors -> first('city')); ?></small>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="form-group">
    <label for="classes"></label>
    <input type="text" name="classes" class="form-control" value="<?php echo e(old ('classes')); ?>"
        placeholder="Lớp học bạn muốn đăng kí">
    <?php if($errors->has('classes')): ?>
    <small class="invalid-feedback"><?php echo e($errors -> first('classes')); ?></small>
    <?php endif; ?>
</div>
<div class="form-group">
    <label for="message"></label>
    <textarea name="message" id="message" cols="30" rows="7" class="form-control"
        placeholder="Tin Nhắn Của Bạn Cho Chúng Tôi"></textarea>
</div>
<div class="row justify-content-center">
    <div class="form-group">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary py-3 px-5">Gửi Đi</button>
    </div>
</div><?php /**PATH C:\laragon\www\vlady\resources\views/classes/register-form.blade.php ENDPATH**/ ?>