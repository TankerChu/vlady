<?php $__env->startSection('banner'); ?>
<section class="hero-wrap js-fullheight">
	<div class="overlay" style="background-image: url('<?php echo e(asset('images/banner-1.jpg')); ?> ');"
		data-stellar-background-ratio="1"></div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="ftco-section" style="font-family: Roboto;">
	<div class="container">
		<div class="row justify-content-center mb-5">
			<div class="col-md-10 heading-section text-center ftco-animate">
				<span class="subheading">
					<i class="db-left"></i>
					Khóa Học Trực Tiếp
					<i class="db-right"></i>
				</span>
				<h2 class="mb-3">Các khóa học Trực Tiếp Sắp Khai Giảng</h2>
				<p></p>
			</div>
		</div>
		<div class="row justify-content-center">
			<?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="col-md-4">
				<div class="pricing-wrap ftco-animate img"
					style="background-image: url( <?php echo e($courses->getFirstMediaUrl('courses_cover')); ?> );">
					<div class="title p-4">
						<h3> <?php echo e($courses->name); ?> </h3>
						<span> <?php echo e($courses->date_time); ?> </span>
					</div>
					<div class="text p-4 d-flex align-items-end">
						<a href="<?php echo e(route('course', [$courses->slug, $courses->id])); ?>"
							class="btn-custom px-4 py-2">Tham
							Gia
							Ngay</a>
						<div>
							<span class="price"> Liên Hệ </span>
							<h3><a href="#"> <?php echo e($courses->address); ?> </a></h3>
							<?php
							echo $courses->introduction
							?>
						</div>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<div class="container">
				<div class="row justify-content-center mb-5">
					<div class="col-md-10 heading-section text-center ftco-animate">
						<h2 class="mb-3" style="color:coral">Xin lỗi!!! Hiện tại chưa có khóa học nào. Xin hãy quay lại
							sau!!!
						</h2>
					</div>
				</div>
				<?php endif; ?>
			</div>
		</div>
</section>
<!-- hết phần khóa học trực tiếp -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vlady\resources\views/classes/classes.blade.php ENDPATH**/ ?>